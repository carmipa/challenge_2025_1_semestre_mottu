package br.com.fiap.mattu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MottuApplicationTests {

	@Test
	void contextLoads() {
	}

}
